#. To use this module, you need to add ``widget="signature"`` to your binary
   field in your view.
#. You can specify signature dimensions like the following:
   ``<field name="signature_image" widget="signature" width="400"
   height="100"/>``
