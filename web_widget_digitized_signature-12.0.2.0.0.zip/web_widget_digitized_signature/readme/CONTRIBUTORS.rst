* Jay Vora <jay.vora@serpentcs.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Pedro M. Baeza <pedro.baeza@gmail.com>
* Vicent Cubells <vicent@vcubells.net>
* Mayank Gosai <mgosai@opensourceintegrators.com>
* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
