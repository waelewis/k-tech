This module provides a widget for binary fields that allows to digitize a
signature and store it as an image.

As demonstration, it includes this widget at user level, so that we can store
a signature image for each user.
