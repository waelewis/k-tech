#. Go to *Settings > Users > Users*.
#. Open one of the existing users.
#. You can set a digital signature for it on the field "Signature".
